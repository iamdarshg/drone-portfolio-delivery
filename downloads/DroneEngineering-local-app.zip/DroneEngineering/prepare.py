"""Reproducible small asset staging; never runs repository code."""
import hashlib, json, shutil, subprocess, urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
ASSETS = HERE / 'assets'
ASSETS.mkdir(exist_ok=True)
def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args]).decode().strip()
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
inventory = []
checks = []
repos = []
for name in ['drone-arm', 'drone-mech']:
    repo = Path('D:/CodeProjects') / name
    url = 'https://api.github.com/repos/iamdarshg/' + name
    with urllib.request.urlopen(url) as response:
        info = json.load(response)
        checks.append({'url': url, 'status': response.status, 'private': info['private']})
    with urllib.request.urlopen(url + '/commits/' + info['default_branch']) as response:
        commit = json.load(response)['sha']
    with urllib.request.urlopen(url + '/git/trees/' + commit + '?recursive=1') as response:
        tree = [e['path'] for e in json.load(response)['tree'] if e['type'] == 'blob']
    candidates = (['README.md', 'RELEASE_STATUS.md', 'docs/hardware/VALIDATION_MATRIX.md', 'hardware/motor_release/FA4119_PROPULSION_DECISION.md'] if name == 'drone-arm' else ['README.md', 'highspeed_edf/deliverables/phase15_geometry/reports/phase15_geometry_manufacturing_report.md'])
    files = [p for p in candidates if p in tree]
    if len(files) < 2:
        files += [p for p in tree if p.endswith('.py')][:2]
    cached = []
    for i, p in enumerate(files):
        with urllib.request.urlopen('https://raw.githubusercontent.com/iamdarshg/' + name + '/' + commit + '/' + p) as response:
            raw = response.read()
        target = ASSETS / (name + '-' + str(i) + '.txt')
        target.write_bytes(raw)
        cached.append({'path': p, 'cache': 'assets/' + target.name, 'sha256': sha(target)})
    with urllib.request.urlopen('https://github.com/iamdarshg/' + name) as r:
        checks.append({'url': r.url, 'status': r.status})
    with urllib.request.urlopen(url + '/commits/' + commit) as r:
        checks.append({'url': r.url, 'status': r.status})
    repos.append({'name': name, 'commit': commit, 'branch': info['default_branch'], 'files': cached})
arm = Path('D:/CodeProjects/drone-arm')
for source in ['hardware/esc/rev_b/reports/esc_final_top.png', 'hardware/esc/rev_b/reports/esc_final_bottom.png']:
    src = arm / source
    shutil.copyfile(src, ASSETS / src.name)
    history = git(arm, 'log', '-1', '--format=%H', '--', source)
    inventory.append({'file': 'assets/' + src.name, 'source': source, 'sha256': sha(src), 'kind': 'Existing PCB render, not a photograph', 'last_path_commit': history or None, 'note': 'Local source bytes hashed; render does not establish current-board release readiness.'})
parts = ROOT / 'OneLine/assets/film_parts'
manifest = json.loads((parts / 'manifest.json').read_text())
for name in ['duct_A_rotor_R1_N13', 'real_motor_housing']:
    entry = next(p for p in manifest['parts'] if p['name'] == name)
    src = parts / (name + '.stl')
    shutil.copyfile(src, ASSETS / src.name)
    step = Path(entry['source'])
    repo = arm if name.startswith('real_motor') else Path('D:/CodeProjects/drone-mech')
    relative = step.relative_to(repo).as_posix()
    history = git(repo, 'log', '-1', '--format=%H', '--', relative)
    matches = False
    if history:
        blob = subprocess.check_output(['git', '-C', str(repo), 'show', history + ':' + relative])
        matches = hashlib.sha256(blob).hexdigest() == entry['sha256']
    inventory.append({'file': 'assets/' + src.name, 'sha256': sha(src), 'source_step': relative, 'source_step_sha256': entry['sha256'], 'source_repository': repo.name, 'last_path_commit': history, 'step_matches_commit': matches, 'derivation': 'Existing OneLine/prepare_film_assets.py: CadQuery importStep; export tolerance=0.08, angularTolerance=0.15; full solid (no section cutter). STL bytes copied unchanged, not regenerated.', 'status': 'Historical superseded custom motor CAD' if name.startswith('real_motor') else 'Phase-15 rotor concept; packaging collisions unresolved'})
shutil.copyfile(ROOT / 'OneLine/prepare_film_assets.py', ASSETS / 'prepare_film_assets.py.txt')
(HERE / 'data.json').write_text(json.dumps({'repositories': repos, 'assets': inventory, 'checks': checks}, indent=2))
print(json.dumps({'checks': checks, 'assets': inventory}, indent=2))
