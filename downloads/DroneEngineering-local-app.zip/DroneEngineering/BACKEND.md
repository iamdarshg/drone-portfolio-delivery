# Local code workspace backend

`serve.py` provides the implemented backend for the read-only editor-style UI:

- `GET /api/snapshot?repo=drone-arm&refresh=1` — public default branch, resolved commit/date, bounded file tree, cache/bundled fallback. Also supports `repo=drone-mech`.
- `GET /api/file?repo=drone-arm&commit=<40-character-sha>&path=README.md` — bounded inert bytes from that repository/commit; cached per exact repo/commit/path.
- `GET /api/directory?repo=drone-arm&commit=<40-character-sha>&path=docs` — lazy directory children for truncated recursive trees; cached exact revision/path, maximum 1,000 entries with explicit limit flag. The UI retains folder hierarchy, lazily creates child DOM on expansion, and links to GitHub if that directory is limited. Offline truncated listings are labeled as partial through the more-on-GitHub link.
- Refresh is rate-limited by a 20-second snapshot cache cooldown. Local writable `.cache` is excluded from source packages and blocked from HTTP browsing.

No POST/write/terminal/extension/runtime APIs, credentials, cloning, archive extraction or executable repository loading. Allowed repositories are fixed internally. Path traversal and unknown repositories are rejected. GitHub requests have 10-second timeouts and 1.5 MB response caps; the UI adds preview limits. Server binds 127.0.0.1. The launcher opens the browser on an available port.

This is a functional local code-browsing backend with a VS Code-style frontend, **not Microsoft VS Code, code-server or OpenVSCode Server**. No corresponding CLI was found on PATH during packaging. No IDE SDK/server was installed. External github.dev links are available; they do not run an embedded local IDE. Python source package requires a separately installed Python 3.10+.

Expiry and static fallback: APP.md. Test evidence: app-test-results.json; launcher browser-open and running-server expiry shutdown were also verified with mocked clock/expiry behavior.
