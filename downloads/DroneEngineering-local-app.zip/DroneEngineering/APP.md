# Drone engineering local app

## Windows, Linux and macOS

Public delivery source: **https://github.com/iamdarshg/drone-portfolio-delivery**, main at recorded short commit **18a605a**. Manifest: SOURCE_REPOSITORY.json. Run `Clone-Delivery.cmd`, `bash Clone-Delivery.sh`, or `bash Clone-Delivery.command` explicitly. Public HTTPS cloning requires no login; no token is embedded. Network/Git errors preserve files and return failure; existing destinations are skipped. The clone resolves current HEAD; 18a605a records the original push, not a fixed future HEAD. No visibility changes are performed by the app.

- Windows: `WindowsStart.cmd` (or `Start.cmd`).
- Linux: `bash Start.sh`.
- macOS: `bash Start.command` (or double-click Start.command when executable and permitted by local security policy).
- Clone source: Windows `Clone-Repositories.cmd`; Linux `bash Clone-Repositories.sh`; macOS `bash Clone-Repositories.command`.

All use the same standard-library Python 3.10+ server, `webbrowser` default-browser opening, dynamic loopback port and UTC expiry. The web app does not require Git; cloning does. No installers/admin/services. Shell launchers handle spaces in their paths. ZIP entries preserve executable bits; if an extractor drops permissions, `bash Start.sh` / `bash Start.command` still works. Python/browser installation and macOS security prompts remain machine-specific. Windows runtime was tested; native Linux/macOS runtime was not available and is not claimed tested.

The delivery URL is taken from the supplied SOURCE_REPOSITORY.json. Preview: `python3 clone_repositories.py --delivery --dry-run`. Only HTTPS repository URLs owned by iamdarshg are accepted; no repository content executes. This small app ZIP does not itself contain video/diffusion bulk; the delivery repository has separate content/status recorded in its manifest.

## Clone source repositories

Run **Clone-Repositories.cmd** explicitly to clone both public HTTPS repositories into `repos` beside the extracted app. This is separate from app startup; nothing clones automatically. Requires separately installed Git and Python 3.10+. Existing destinations are always skipped, never reset, overwritten or pulled. No repository code, hooks or submodules execute. Newly cloned HEAD commits and fetch timestamps are recorded in `repos/clone-results.json`; existing reports are preserved. Failed/partial clone files are left intact. Missing Git prints direct source-ZIP links; no software is installed automatically.

Custom destination: `python clone_repositories.py --destination "D:\MySources"`. Preview only: `python clone_repositories.py --dry-run`. The browser frontend cannot execute a local shell; use the named launcher in the extracted package.

Extract the ZIP to a writable folder, then double-click **Start.cmd** on Windows. Requires **Python 3.10+**, installed separately from python.org. No git, npm, admin access, GPU or services. The launcher selects an available local port and opens the default browser. Close the terminal or press Ctrl+C to stop. No standalone EXE was built: PyInstaller is not installed; no packaging dependencies were downloaded.

Manual launch: `python serve.py 0 --open`. The server binds **127.0.0.1 only**. It does not create a tunnel or public URL.

On load / Refresh, the backend resolves the latest public default-branch commit of `iamdarshg/drone-arm` and `iamdarshg/drone-mech`. A 20-second refresh cooldown limits API requests. Trees are bounded to 6,000 files, previews to 1.5 MB on the backend / 750 KB in the explorer, requests time out after 10 seconds. Last successful repository metadata and up to 100 fetched text files are cached in `.cache`. Offline or rate-limited access uses cache, then bundled source. A cached tree does not imply every file has been downloaded. No clones, ZIP extraction, credentials or repository code execution. Markdown is a safe DOM-only subset: headings, paragraphs, lists, links, bold, inline/fenced code; raw HTML remains literal text. Links only allow HTTP(S). Syntax coloring is lightweight lexical highlighting, not a full IDE. github.dev is external.

Media sections are visible only after actual image/mesh success. Failed photos and CAD/PCB loads occupy no layout space. Source fallback remains functional. Model rotation, tilt, zoom, reset, model selection and PCB view selection run locally. STEP is not rendered in-browser. Physical-build photos never replace factual engineering status; manifest includes capture/contribution metadata. Supplied CAD/PCB renders are not physical validation.

`config.json` chooses **2027-10-01T00:00:00Z** as expiry. On/after that date the dynamic server refuses startup and a running server shuts itself down within approximately one second. No self-delete or file modification is performed by expiry. This uses the local system clock/configuration and is **not tamper-proof**. Static files remain usable: from this folder run `python -m http.server 8765 --bind 127.0.0.1`; open localhost:8765. Static mode falls back to bundled/pinned GitHub content without local APIs.

Source history is in data.json. The latest code view and pinned bundled snapshot are separate versions. No public deployment exists. Photos may be later additions; institutional acceptance of updates is not assumed. Package is unsigned Python source; OS/browser trust prompts and Python installation vary by machine.
