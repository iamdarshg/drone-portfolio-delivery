# Drone engineering

**Downloadable local app:** see `APP.md` for launch, cache, expiry and security details. Windows: extract the package, install Python 3.10+ if absent, double-click `Start.cmd`. No standalone EXE or public deployment.

Manual: `python serve.py 0 --open`. Localhost only. Dynamic startup and the running server expire October 1, 2027 UTC, using the local clock; no deletion or tamper-proof guarantee. Bundled static content remains available independently.

Code: bounded read-only GitHub explorer, latest public default-branch commits, Refresh, automatic formatted README, tabbed text files, lightweight syntax coloring, bundled/cache fallback. No repo scripts execute. Only HTTP(S) links are emitted by the DOM-only Markdown renderer. Full HTML/Markdown extensions are deliberately unsupported.

Design: real existing PNG/STL files, source paths/hashes in `data.json`. Four local STL parts with rotate/tilt/zoom/reset and download. Failed media sections disappear entirely. Source-history and development-photo sections are secondary. Existing models/renders are not physical tests; board release blocked, packaging collisions unresolved, custom motor historical/superseded. Credits include Ethan, contributors and AI tooling; individual task attribution pending confirmation.

Future photo metadata lives in `photos.json`. Owner uploads manually through normal GitHub UI:
- drone-arm / `docs/media/build/01-board-assembly.jpg` / Board assembly
- drone-mech / `docs/media/build/01-airframe-assembly.jpg` / Airframe assembly

Set real capture date, factual completed/WIP status, caption, photographer credit and physical contribution before upload. No upload API, credentials or visibility changes are provided. Latest-branch photos are live supplements, not proof of deadline evidence; institutional update rules are unknown. Missing photos have no visible section.

`test_app.py` verifies current app; Playwright is a test-only dependency. `app-test-results.json` records results. Historical `test_demo.py`/`test-results.json` describe the earlier static iteration, not the current test suite. `package_app.py` builds source ZIP on E:, excluding local cache/bytecode. `download-package.json` indexes the resulting path/hash. No bulk artifacts are stored here.
