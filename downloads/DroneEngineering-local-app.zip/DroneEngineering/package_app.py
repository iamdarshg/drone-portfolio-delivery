"""Build source ZIP on E:, no external dependencies or executable bundling."""
import hashlib,json,zipfile
from pathlib import Path
root=Path(__file__).resolve().parent
out=Path('E:/OneLine_final_media/app');out.mkdir(parents=True,exist_ok=True)
target=out/'DroneEngineering-local-app.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as archive:
    for file in root.rglob('*'):
        relative=file.relative_to(root)
        if file.is_file() and not any(p in {'.cache','__pycache__','repos'} for p in relative.parts):
            info=zipfile.ZipInfo.from_file(file,'DroneEngineering/'+relative.as_posix())
            if file.suffix in {'.sh','.command'}:
                info.create_system=3
                info.external_attr=(0o100755 << 16)
            archive.writestr(info,file.read_bytes(),compress_type=zipfile.ZIP_DEFLATED)
manifest={'zip':str(target),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'entry_point':'DroneEngineering/Start.cmd','requires':'Python 3.10+','public_deployment':False}
(root/'download-package.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps(manifest,indent=2))
