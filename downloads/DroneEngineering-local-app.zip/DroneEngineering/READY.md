# Local app ready checklist

- [x] Windows Start.cmd; Python 3.10+ dependency explicit; loopback server opens default browser on an available port.
- [x] Functional local APIs: latest public revision/date/tree and read-only file content, bounded timeout/cache and fallback.
- [x] Automatic README Markdown, file filter, tabs and syntax coloring; raw repository code never executes.
- [x] Actual top/bottom PCB renders and four source-derived STL meshes with rotation/tilt/zoom/reset/download.
- [x] Failed media sections hidden; tested 404/offline, working media visible.
- [x] Engineering status and contributor credits factual; source history collapsed; no reviewer-directed UI copy.
- [x] Sticky section navigation/progress, restrained transitions, reduced-motion support and mobile layout.
- [x] Desktop/mobile screenshots inspected; test results in app-test-results.json.
- [x] Expiry startup refusal and running-server shutdown tested using mocked expiry; no self-deletion.
- [x] Download package indexed in download-package.json; ZIP/screenshot bulk on E:.
- [ ] Public deployment: not performed, no public URL.
- [ ] Real VS Code web server: not installed or represented as this app. This is a read-only editor-style workspace with its own implemented backend.

Launch: extract ZIP, run Start.cmd. Manual: `python serve.py 0 --open`.
